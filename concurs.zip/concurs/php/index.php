<?php include 'database.php'; ?>
<?php
  $query = "SELECT * FROM questions";
  $results= $mysqli->query($query) or die($mysqli->error_LINE_);
  $total= $results->num_rows;
 ?>

<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Quizzer</title>
    <link rel="stylesheet" type="text/css" href="../css/style_quiz.css">
  </head>
  <body>

      <main>
        <div class="container">
        <h2 class="title">Quiz</h2>
        <ul>
          <li><strong>Number of questions: </strong><?php echo $total; ?></li>
          <li><strong>Type: </strong> Multiple Choice</li>
          <li><strong>Estimated Time: </strong><?php echo $total * .5; ?> Minutes</li>
        </ul>
        <a href="question.php?n=1" class="start">Start Quiz</a>
      </div>
      </main>
  </body>
</html>
