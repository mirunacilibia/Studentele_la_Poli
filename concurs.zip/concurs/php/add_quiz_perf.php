<?php include 'database.php'; ?>
<?php session_start(); ?>
<?php

    if(isset($_POST['submit'])){
      $level1 = $_POST['level1'];
      $level2 = $_POST['level2'];
      $number_of_players = $_POST['number_of_players'];

      $query = "INSERT INTO `newquiz`(level1, level2 , number_of_players)
                VALUES('$level1','$level1', '$number_of_players')";

      $insert_row = $mysqli->query($query) or die($mysqli->error);

    $query = "SELECT * FROM newquiz ";
    $questions1 = $mysqli->query($query) or die($mysqli->error._LINE_);
    $total1 =  $questions1->num_rows;
    $next1 = $total1+1;
    }
 ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Quizzer</title>


    <link rel="stylesheet" type="text/css" href="../css/style_quiz_adaugare.css">

  </head>
  <body>

      <main>
        <div class="container">
        <h2 class="title">Add a quiz!</h2>
        <form method="post" action="add_quiz_perf.php">
          <p>
            <label>Number of Level 1 Questions: </label>
            <input type="number" name="level1" />
          <p/>
          <p>
            <label>Number of Level 2 Questions: </label>
            <input type="number" name="level2" />
          <p/>
          <p>
            <label>Number of Players: </label>
            <input type="number" name="number_of_players" />
          <p/>
          <p>
            <input type="submit" name="submit" value="Submit"/>
          <p/>
        </form>
      </div>

      <div class="buton1">
        <a href="add.php">
        <p>Add</p>
        <p>Questions!</p>
        </a>
      </div>
      <div class="buton2">
        <a href="add_quiz_perf.php">AddQuiz!</a>
      </div>
      </main>
  </body>
</html>
