<?php include 'database.php'; ?>
<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Quizzer</title>

    <link rel="stylesheet" type="text/css" href="../css/style_quiz_final.css">

  </head>
  <body>
      <main>
        <div class="container">
          <h2>You're done!</h2>
          <p>Congrats! You have completed the test!</p>
          <p>Final Score: <?php echo $_SESSION['score']; ?></p>
          <form method="post" action="leaderboard.php">
            <p>
              <label>Your Name: </label>
              <input type="text" name="name" />
              <input type="submit" name="submit" value="View Leaderboard" />
            <p/>
          </form>

      </div>
      </main>
  </body>
</html>
