<?php include 'database.php'; ?>
<?php session_start(); ?>
<?php
  if(isset($_POST['submit'])){
    $name = $_POST['name'];
    $score = $_SESSION['score'];
    $query = "INSERT INTO leaderboard (name, score)
              VALUES ('$name','$score')";
    $insert_row = $mysqli->query($query) or die($mysqli->error);
  }
    $query = "SELECT * FROM leaderboard"; //You don't need a ; like you do in SQL
    $result = $mysqli->query($query) or die($mysqli->error.__LINE__);
    echo "<table>
    <tr>
<th>Name</th>
<th>Score</th>
</tr>"; // start a table tag in the HTML
    while($row = $result->fetch_assoc()){   //Creates a loop to loop through results
      echo "<tr><td>" . $row['name'] . "</td><td>" . $row['score'] . "</td></tr>";  //$row['index'] the index here is a field name
}

      echo "</table>"; //Close the table in HTML
 ?>
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>Quizzer</title>


     <link rel="stylesheet" type="text/css" href="../css/style_quiz_admin.css">

   </head>
   <body>
       <main>
         <table id="customers" align="" >

         </table>
       </main>
   </body>
 </html>
