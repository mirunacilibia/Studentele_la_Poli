<html>
<head>
<title>Sign Up Form Design</title>
    <link rel="stylesheet" type="text/css" href="./css/style_signup.css">
<body>
    <div class="loginbox">
    <img src="./img/avatar.png" class="avatar">
        <h1>Sign Up</h1>
        <form method="post" action="EmailVer.php" >
            <p>Name</p>
            <input type="text" name="name" placeholder="Enter Name" required autofocus>
            <p>Email</p>
            <input type="email" name="email" placeholder="Enter Email" required >
            <p>Password</p>
            <input type="password" name="password" placeholder="Enter Password" required>
            <p>Phone Number</p>
            <input type="tel" name="phone_number" placeholder="Enter Phone Number" required>
            <input type="submit" name="submit" value="Sign Up">
        </form>
    </div>

</body>
</head>
</html>
