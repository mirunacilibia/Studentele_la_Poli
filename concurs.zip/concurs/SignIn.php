<html>
<head>
<title>Login Form Design</title>
    <link rel="stylesheet" type="text/css" href="./css/style_login.css">
<body>
    <div class="loginbox">
    <img src="./img/avatar.png" class="avatar">
        <h1>Sign In Here</h1>
        <form action="./php/index.php">
            <p>Email</p>
            <input type="email" name="" placeholder="Enter Email" required autofocus>
            <p>Password</p>
            <input type="password" name="" placeholder="Enter Password" required>
            <input type="submit" name="" value="Login" /SignUp.html>
            <a href="SignUp.php">Don't have an account?</a>
        </form>

    </div>

</body>
</head>
</html>
