<?php include './php/database.php'; ?>
<?php session_start(); ?>
<?php
    if(isset($_POST['submit'])){

      $email = $_POST['email'];
      $name = $_POST['name'];
      $password = $_POST['password'];
      $phone_number = $_POST['phone_number'];

      $query = "INSERT INTO `user`(email, name, password, phone_number)
                VALUES('$email','$name','$password','$phone_number')";

      $insert_row = $mysqli->query($query) or die($mysqli->error.__LINE__);

    }
 ?>

<html>
<head>
<title>Confiramtion Email</title>
      <link rel="stylesheet" type="text/css" href="./css/style_email.css">
<body>
    <div class="loginbox">
        <h1>Confirmation Email sent</h1>
        <form action="./php/index.php">
            <input type="submit" name="" value="Go to Quiz">
        </form>

    </div>

</body>
</head>
</html>
