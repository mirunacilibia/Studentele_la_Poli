const score[10]=getElementsByTagName("score");
let nrParticipants;
let i, j, k, aux;

for(i=1; i<=(rows.length - 1); i++)
{
    for(j=i+1; j<=(rows.length); j++)
    {
      if(score[i]<score[j])
      {
        aux=score[i];
        score[i]=score[j];
        score[j]=aux;
      }
    }
}
